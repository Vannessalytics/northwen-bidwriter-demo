# Northwen BidWriter License Management

This directory contains tools and documentation for managing software licenses.

## Overview

Northwen BidWriter uses ES256 (ECDSA with P-256 and SHA-256) JWT tokens for offline license verification. This ensures the application can validate licenses without requiring internet connectivity.

## Files

- `public_key.pem` - Public key for license verification (placeholder)
- `license_generator.py` - Script for generating licenses (seller only)
- `license_validator.py` - Script for validating licenses (testing)

## License Format

Licenses are JWT tokens with the following structure:

### Header
```json
{
  "alg": "ES256",
  "typ": "JWT"
}
```

### Payload
```json
{
  "iss": "Northwen",
  "sub": "customer-id",
  "aud": "northwen-bidwriter",
  "exp": 1735689600,
  "iat": 1704153600,
  "nbf": 1704153600,
  "jti": "license-uuid",
  "customer": {
    "name": "Customer Company Name",
    "email": "contact@customer.com",
    "id": "customer-unique-id"
  },
  "product": {
    "name": "Northwen BidWriter",
    "version": "1.0",
    "edition": "professional"
  },
  "features": {
    "max_users": 10,
    "max_rfps_per_month": 100,
    "cloud_api": true,
    "advanced_templates": true,
    "custom_branding": false
  },
  "limits": {
    "concurrent_sessions": 5,
    "storage_gb": 50
  }
}
```

### Signature
The signature is generated using the seller's private ES256 key.

## Key Generation (Seller Only)

To generate a new key pair:

```bash
# Generate private key
openssl ecparam -genkey -name prime256v1 -noout -out private_key.pem

# Extract public key
openssl ec -in private_key.pem -pubout -out public_key.pem

# Verify key pair
openssl ec -in private_key.pem -text -noout
```

**IMPORTANT:** 
- Keep the private key secure and offline
- Only the public key should be included in the application
- Use hardware security modules (HSM) for production key storage

## License Generation Process (Seller Only)

1. Customer purchases license
2. Generate unique customer ID and license UUID
3. Create JWT payload with customer details and feature flags
4. Sign JWT with private key
5. Deliver license file to customer
6. Customer uploads license file to application

## License Validation Process

1. Application reads license file
2. Verifies JWT signature using embedded public key
3. Checks expiration date and validity period
4. Validates audience and issuer claims
5. Extracts feature flags and limits
6. Stores validated license data securely

## License File Format

License files are plain text files with `.nwlic` extension containing the JWT token:

```
eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJOb3J0aHdlbiIsInN1YiI6ImN1c3RvbWVyLWlkIiwiYXVkIjoibm9ydGh3ZW4tYmlkd3JpdGVyIiwiZXhwIjoxNzM1Njg5NjAwLCJpYXQiOjE3MDQxNTM2MDAsIm5iZiI6MTcwNDE1MzYwMCwianRpIjoibGljZW5zZS11dWlkIiwiY3VzdG9tZXIiOnsibmFtZSI6IkN1c3RvbWVyIENvbXBhbnkgTmFtZSIsImVtYWlsIjoiY29udGFjdEBjdXN0b21lci5jb20iLCJpZCI6ImN1c3RvbWVyLXVuaXF1ZS1pZCJ9LCJwcm9kdWN0Ijp7Im5hbWUiOiJOb3J0aHdlbiBCaWRXcml0ZXIiLCJ2ZXJzaW9uIjoiMS4wIiwiZWRpdGlvbiI6InByb2Zlc3Npb25hbCJ9LCJmZWF0dXJlcyI6eyJtYXhfdXNlcnMiOjEwLCJtYXhfcmZwc19wZXJfbW9udGgiOjEwMCwiY2xvdWRfYXBpIjp0cnVlLCJhZHZhbmNlZF90ZW1wbGF0ZXMiOnRydWUsImN1c3RvbV9icmFuZGluZyI6ZmFsc2V9LCJsaW1pdHMiOnsiY29uY3VycmVudF9zZXNzaW9ucyI6NSwic3RvcmFnZV9nYiI6NTB9fQ.signature-here
```

## Error Handling

The application handles various license validation errors:

- **License not found**: Prompts user to upload license
- **Invalid signature**: License has been tampered with
- **Expired license**: License has passed expiration date
- **Not yet valid**: License start date is in the future
- **Wrong audience**: License is for different product
- **Feature disabled**: Requested feature not included in license

## Grace Periods

The application includes a 7-day grace period for expired licenses to account for:
- Clock skew between systems
- Renewal processing delays
- Customer convenience

During the grace period:
- Application shows expiration warnings
- Core functionality remains available
- New features may be disabled

## Security Considerations

- JWT tokens are stateless and cannot be revoked
- Keep license files secure to prevent unauthorized copying
- Monitor for license sharing or abuse
- Consider implementing online license validation for high-value customers
- Use short expiration periods for trial licenses

## Testing

Use the provided test scripts to validate license generation and verification:

```bash
# Generate test license (requires private key)
python license_generator.py --customer "Test Customer" --email "test@example.com"

# Validate license
python license_validator.py --license test_license.nwlic
```

## Support

For license-related issues:
1. Check application logs for detailed error messages
2. Verify license file integrity
3. Confirm system clock accuracy
4. Contact support with license UUID for assistance
