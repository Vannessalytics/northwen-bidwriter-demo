import { contextBridge, ipcRenderer } from 'electron';

// Security: Expose only necessary APIs to renderer
const electronAPI = {
  // Engine communication
  getEngineConfig: () => ipcRenderer.invoke('get-engine-config'),
  
  // File system operations
  showSaveDialog: (options: any) => ipcRenderer.invoke('show-save-dialog', options),
  showOpenDialog: (options: any) => ipcRenderer.invoke('show-open-dialog', options),
  showMessageBox: (options: any) => ipcRenderer.invoke('show-message-box', options),
  
  // External operations
  openExternal: (url: string) => ipcRenderer.invoke('open-external', url),
  showItemInFolder: (path: string) => ipcRenderer.invoke('show-item-in-folder', path),
  
  // App info
  getAppVersion: () => ipcRenderer.invoke('get-app-version'),
  getAppPath: (name: string) => ipcRenderer.invoke('get-app-path', name),
  
  // Platform info
  platform: process.platform,
  
  // Event listeners
  on: (channel: string, callback: Function) => {
    const validChannels = ['update-available', 'update-downloaded', 'engine-status'];
    if (validChannels.includes(channel)) {
      ipcRenderer.on(channel, (event, ...args) => callback(...args));
    }
  },
  
  removeAllListeners: (channel: string) => {
    ipcRenderer.removeAllListeners(channel);
  }
};

// Security: Only expose our API
contextBridge.exposeInMainWorld('electronAPI', electronAPI);

// Type definitions for renderer
export interface ElectronAPI {
  getEngineConfig(): Promise<{
    port: number;
    secret: string;
    baseUrl: string;
  }>;
  showSaveDialog(options: any): Promise<{ canceled: boolean; filePath?: string }>;
  showOpenDialog(options: any): Promise<{ canceled: boolean; filePaths: string[] }>;
  showMessageBox(options: any): Promise<{ response: number }>;
  openExternal(url: string): Promise<void>;
  showItemInFolder(path: string): Promise<void>;
  getAppVersion(): Promise<string>;
  getAppPath(name: string): Promise<string>;
  platform: string;
  on(channel: string, callback: Function): void;
  removeAllListeners(channel: string): void;
}

declare global {
  interface Window {
    electronAPI: ElectronAPI;
  }
}
