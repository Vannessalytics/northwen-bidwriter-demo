import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { Toaster } from '@/components/ui/toaster';
import { ThemeProvider } from '@/components/theme-provider';
import { I18nProvider } from '@/lib/i18n';
import { useAppStore } from '@/lib/store';

// Route components
import { FirstRunWizard } from '@/routes/first-run-wizard';
import { Dashboard } from '@/routes/dashboard';
import { Upload } from '@/routes/upload';
import { RfpDetail } from '@/routes/rfp-detail';
import { DraftEditor } from '@/routes/draft-editor';
import { Exports } from '@/routes/exports';
import { Settings } from '@/routes/settings';

// Layout components
import { AppLayout } from '@/components/layout/app-layout';
import { LoadingScreen } from '@/components/ui/loading-screen';
import { ErrorBoundary } from '@/components/ui/error-boundary';

// Create a client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      retry: (failureCount, error: any) => {
        // Don't retry on 4xx errors
        if (error?.status >= 400 && error?.status < 500) {
          return false;
        }
        return failureCount < 3;
      },
    },
  },
});

function AppRoutes() {
  const { isFirstRun, isLoading } = useAppStore();

  if (isLoading) {
    return <LoadingScreen />;
  }

  if (isFirstRun) {
    return <FirstRunWizard />;
  }

  return (
    <AppLayout>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/upload" element={<Upload />} />
        <Route path="/rfp/:id" element={<RfpDetail />} />
        <Route path="/rfp/:id/editor" element={<DraftEditor />} />
        <Route path="/exports" element={<Exports />} />
        <Route path="/settings/*" element={<Settings />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </AppLayout>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider defaultTheme="light" storageKey="nw-ui-theme">
          <I18nProvider>
            <Router>
              <div className="min-h-screen bg-background font-sans antialiased">
                <AppRoutes />
                <Toaster />
              </div>
            </Router>
            <ReactQueryDevtools initialIsOpen={false} />
          </I18nProvider>
        </ThemeProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;
