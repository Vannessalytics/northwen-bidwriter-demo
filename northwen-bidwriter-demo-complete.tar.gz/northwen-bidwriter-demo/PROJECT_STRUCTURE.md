.
├── assets
│   ├── av-seed
│   ├── fonts
│   └── icons
├── build
│   └── entitlements.mac.plist
├── build.sh
├── docs
│   └── README_INSTALL_DESKTOP.md
├── .editorconfig
├── electron-main
│   ├── main.ts
│   ├── preload.ts
│   └── tsconfig.json
├── engine
│   ├── engine.spec
│   ├── requirements
│   ├── requirements.txt
│   └── src
│       ├── api
│       ├── av
│       ├── core
│       │   ├── config.py
│       │   └── security.py
│       ├── export
│       ├── main.py
│       ├── models
│       ├── ocr
│       └── packaging
├── .gitignore
├── package.json
├── packages
│   ├── models
│   │   └── models.yaml
│   ├── samples
│   │   └── mini-rfp
│   │       └── sample_rfp.md
│   └── templates
│       ├── canada-buys
│       │   └── template.yaml
│       └── sam-gov
├── PROJECT_STRUCTURE.md
├── README.md
├── renderer
│   ├── index.html
│   ├── package.json
│   ├── postcss.config.js
│   ├── public
│   ├── src
│   │   ├── App.tsx
│   │   ├── assets
│   │   │   ├── i18n
│   │   │   │   ├── en-CA.json
│   │   │   │   └── fr-CA.json
│   │   │   └── themes
│   │   │       └── globals.css
│   │   ├── components
│   │   ├── hooks
│   │   ├── lib
│   │   │   ├── api.ts
│   │   │   ├── i18n.tsx
│   │   │   └── store.ts
│   │   ├── main.tsx
│   │   └── routes
│   ├── tailwind.config.js
│   ├── tsconfig.json
│   ├── tsconfig.node.json
│   └── vite.config.ts
├── tests
│   ├── e2e
│   │   └── first-run-wizard.spec.ts
│   ├── fixtures
│   │   ├── licenses
│   │   └── rfps
│   ├── playwright.config.ts
│   └── unit
├── tools
│   └── license
│       ├── public_key.pem
│       └── README.md
└── tsconfig.json

42 directories, 39 files
