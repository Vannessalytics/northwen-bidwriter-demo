# Desktop Installation Guide

This guide walks you through installing Northwen BidWriter on Windows and macOS.

## System Requirements

### Minimum Requirements
- **Operating System**: Windows 10 (1903+) or macOS 10.15+
- **Processor**: Intel/AMD x64 or Apple Silicon (M1/M2)
- **Memory**: 8GB RAM
- **Storage**: 10GB free disk space
- **Display**: 1280x720 resolution

### Recommended Requirements
- **Memory**: 16GB+ RAM (for better AI performance)
- **Storage**: 20GB+ free space (for models and data)
- **Storage Type**: SSD (for faster document processing)
- **Display**: 1920x1080+ resolution

## Windows Installation

### Step 1: Download the Installer

1. Visit the [Northwen BidWriter releases page](https://github.com/northwen/bidwriter/releases)
2. Download the latest `Northwen-BidWriter-Setup-x.x.x.exe` file
3. Save the installer to your Downloads folder

### Step 2: Run the Installer

1. **Double-click** the installer file
2. If Windows SmartScreen appears, click **"More info"** then **"Run anyway"**
3. The installer will launch - no administrator privileges required

### Step 3: Installation Wizard

The installer will guide you through these steps:

1. **Welcome Screen**
   - Click **"Next"** to continue

2. **License Agreement**
   - Review the license terms
   - Check **"I accept the agreement"**
   - Click **"Next"**

3. **Installation Location**
   - Default: `C:\Users\{username}\AppData\Local\Programs\Northwen BidWriter`
   - Click **"Browse"** to change location (optional)
   - Click **"Next"**

4. **Additional Tasks**
   - ✅ Create desktop shortcut
   - ✅ Create Start Menu entry
   - ✅ Add to PATH (for command-line access)
   - Click **"Next"**

5. **Ready to Install**
   - Review your choices
   - Click **"Install"**

6. **Installation Progress**
   - Wait for files to be copied (2-3 minutes)
   - The installer will download required components

7. **Completing Setup**
   - ✅ Launch Northwen BidWriter
   - Click **"Finish"**

### Step 4: First Launch

The application will start automatically and show the First-Run Wizard.

## macOS Installation

### Step 1: Download the Installer

1. Visit the [Northwen BidWriter releases page](https://github.com/northwen/bidwriter/releases)
2. Download the latest `Northwen-BidWriter-x.x.x.dmg` file
3. Save the DMG to your Downloads folder

### Step 2: Mount the DMG

1. **Double-click** the DMG file to mount it
2. A new window will open showing the application

### Step 3: Install the Application

1. **Drag** the Northwen BidWriter icon to the Applications folder
2. Wait for the copy to complete (1-2 minutes)
3. **Eject** the DMG by clicking the eject button in Finder

### Step 4: First Launch

1. Open **Applications** folder
2. **Double-click** Northwen BidWriter
3. If macOS shows a security warning:
   - Click **"Cancel"**
   - Go to **System Preferences > Security & Privacy**
   - Click **"Open Anyway"** next to the blocked app message
   - Click **"Open"** in the confirmation dialog

The First-Run Wizard will appear.

## First-Run Wizard

When you launch Northwen BidWriter for the first time, you'll see the setup wizard:

### Step 1: Welcome
- Introduction to Northwen BidWriter
- Click **"Get Started"**

### Step 2: License Agreement
- **Upload License File**: Click to browse for your `.nwlic` file
- **Trial Mode**: Click to start 30-day trial (no license required)
- The license status will show green when valid
- Click **"Next"**

### Step 3: Administrator Setup
- **Full Name**: Enter your name
- **Email Address**: Enter your email
- **Password**: Create a secure password
- **Confirm Password**: Re-enter password
- Click **"Next"**

### Step 4: Language Preferences
Choose your preferred languages:
- **English (Canada)**: For English-only operation
- **Français (Canada)**: For French-only operation  
- **Bilingual (EN/FR)**: For bilingual operation (recommended)
- Click **"Next"**

### Step 5: AI Model Configuration
Choose how to power the AI features:

#### Option A: Local Models (Recommended)
- **Privacy**: All processing on your device
- **Offline**: No internet required after setup
- **Performance**: Optimized for desktop hardware
- Click **"Use Local Models"**

#### Option B: Cloud API (BYOK)
- **OpenAI**: Enter your OpenAI API key
- **Anthropic**: Enter your Anthropic API key
- Keys are stored securely in your system keychain
- Click **"Use Cloud API"**

#### Option C: Ollama Integration
- **Auto-install**: Automatically install Ollama
- **Manual**: Use existing Ollama installation
- Click **"Use Ollama"**

### Step 6: Model Download (Local Models Only)
If you chose local models:
- The wizard will download required models
- **Embedding Model**: ~90MB (for document search)
- **Language Model**: ~4GB (for content generation)
- Progress bars show download status
- **Verify Checksums**: Ensures model integrity
- This may take 10-30 minutes depending on internet speed

### Step 7: Setup Complete
- **Success**: Setup is complete!
- **Launch Application**: Click to start using Northwen BidWriter
- The main dashboard will appear

## Verification

After installation, verify everything is working:

### 1. Check Application Launch
- The application should start without errors
- The dashboard should display properly
- No error messages in the status bar

### 2. Test File Upload
- Click **"Upload New RFP"**
- Try uploading the sample RFP from `Documents/Northwen BidWriter/Samples/`
- The upload should complete successfully

### 3. Check AI Models
- Go to **Settings > Models**
- Verify models show as "Installed" and "Ready"
- Test generation with a simple prompt

### 4. Test Export
- Generate a sample draft
- Export to PDF and DOCX
- Verify files open correctly

## Troubleshooting

### Windows Issues

**"Windows protected your PC" message:**
- Click **"More info"**
- Click **"Run anyway"**
- This is normal for new applications

**Installation fails with permission error:**
- Right-click installer and select **"Run as administrator"**
- Choose a different installation directory
- Ensure you have write permissions to the target folder

**Application won't start:**
- Check Windows Event Viewer for error details
- Try running as administrator
- Reinstall with antivirus temporarily disabled

### macOS Issues

**"App can't be opened because it is from an unidentified developer":**
- Go to **System Preferences > Security & Privacy**
- Click **"Open Anyway"** in the General tab
- Or use: `sudo spctl --master-disable` (not recommended)

**Application is damaged and can't be opened:**
- Download the DMG again (may be corrupted)
- Clear quarantine: `xattr -cr /Applications/Northwen\ BidWriter.app`
- Restart your Mac and try again

**Models fail to download:**
- Check internet connection
- Verify firewall isn't blocking downloads
- Try downloading models manually from Settings

### General Issues

**High memory usage:**
- Close other applications
- Reduce model size in Settings
- Increase virtual memory/swap space

**Slow performance:**
- Use SSD storage if possible
- Close unnecessary browser tabs
- Reduce concurrent processing in Settings

**License issues:**
- Verify license file is valid and not expired
- Check system clock is accurate
- Contact support with license UUID

## Uninstallation

### Windows
1. Go to **Settings > Apps**
2. Find **Northwen BidWriter**
3. Click **"Uninstall"**
4. Follow the uninstaller prompts
5. Manually delete data folder if desired: `%APPDATA%\Northwen BidWriter`

### macOS
1. Drag **Northwen BidWriter** from Applications to Trash
2. Empty Trash
3. Manually delete data folder if desired: `~/Library/Application Support/Northwen BidWriter`

## Data Locations

### Windows
- **Application**: `%LOCALAPPDATA%\Programs\Northwen BidWriter`
- **User Data**: `%APPDATA%\Northwen BidWriter`
- **Logs**: `%APPDATA%\Northwen BidWriter\logs`
- **Models**: `%APPDATA%\Northwen BidWriter\models`

### macOS
- **Application**: `/Applications/Northwen BidWriter.app`
- **User Data**: `~/Library/Application Support/Northwen BidWriter`
- **Logs**: `~/Library/Logs/Northwen BidWriter`
- **Models**: `~/Library/Application Support/Northwen BidWriter/models`

## Getting Help

If you encounter issues during installation:

1. **Check the logs** in the data directory
2. **Search the documentation** for similar issues
3. **Contact support** at support@northwen.com with:
   - Operating system and version
   - Error messages or screenshots
   - Installation log files

## Next Steps

After successful installation:

1. **Read the User Guide** to learn the core workflow
2. **Upload a sample RFP** to test the system
3. **Configure your templates** and boilerplate content
4. **Set up backups** to protect your data
5. **Explore the AI models** and find what works best for you

Welcome to Northwen BidWriter! 🎉
