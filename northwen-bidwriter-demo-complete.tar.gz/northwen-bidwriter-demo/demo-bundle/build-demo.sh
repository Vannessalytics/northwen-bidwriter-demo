#!/bin/bash
# Northwen BidWriter Demo Build Script
# Creates unsigned demo installers for easy distribution

set -e

echo "🎯 Building Northwen BidWriter Demo..."

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[DEMO BUILD]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[DEMO]${NC} $1"
}

# Build demo version
build_demo() {
    print_status "Building demo version..."
    
    # Copy demo license to main app
    cp demo-bundle/license-demo.nwlic packages/license-demo.nwlic
    
    # Copy demo models config
    cp demo-bundle/models-demo.yaml packages/models/models-demo.yaml
    
    # Modify package.json for demo
    sed -i.bak 's/"productName": "Northwen BidWriter"/"productName": "Northwen BidWriter Demo"/' package.json
    sed -i.bak 's/"version": "1.0.0"/"version": "1.0.0-demo"/' package.json
    
    # Build the application
    npm run build
    
    # Create unsigned installers
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS - create unsigned DMG
        npm run package:mac
        print_warning "macOS users will need to right-click → Open to bypass Gatekeeper"
    else
        # Windows - create unsigned EXE
        npm run package:win
        print_warning "Windows users will need to click 'More info' → 'Run anyway'"
    fi
    
    # Restore original files
    mv package.json.bak package.json
    
    print_success "Demo build complete!"
}

# Create demo bundle
create_demo_bundle() {
    print_status "Creating demo bundle..."
    
    # Create demo directory
    mkdir -p dist-demo
    
    # Copy built installers
    if [[ "$OSTYPE" == "darwin"* ]]; then
        cp dist-packages/*.dmg dist-demo/
    else
        cp dist-packages/*.exe dist-demo/
    fi
    
    # Copy demo files
    cp demo-bundle/START-HERE.txt dist-demo/
    cp demo-bundle/license-demo.nwlic dist-demo/
    cp demo-bundle/sample_rfp.pdf dist-demo/
    cp demo-bundle/models-demo.yaml dist-demo/
    
    # Create integrity checksums
    cd dist-demo
    if [[ "$OSTYPE" == "darwin"* ]]; then
        shasum -a 256 *.dmg > checksums.txt
    else
        sha256sum *.exe > checksums.txt
    fi
    cd ..
    
    # Create final demo ZIP
    zip -r "Northwen-BidWriter-Demo-$(date +%Y%m%d).zip" dist-demo/
    
    print_success "Demo bundle created: Northwen-BidWriter-Demo-$(date +%Y%m%d).zip"
}

# Generate demo documentation
create_demo_docs() {
    print_status "Creating demo documentation..."
    
    cat > dist-demo/DEMO-README.md << 'DEMO_EOF'
# Northwen BidWriter Demo

## What This Demo Shows

✅ **Offline-First Architecture** - Disconnect WiFi, it still works!
✅ **AI-Powered RFP Analysis** - Upload RFP → automatic compliance matrix
✅ **Bilingual Generation** - Create proposals in English and French
✅ **Professional Export** - DOCX/PDF with proper formatting
✅ **Security Features** - Antivirus scanning, secure processing
✅ **Local AI Models** - No cloud required, privacy-first

## Demo Limitations

- **14-day trial period**
- **Maximum 3 RFPs** can be processed
- **Demo watermarks** on all exports
- **Basic templates only** (advanced templates in full version)
- **Single user license**

## Installation

### Windows
1. Extract ZIP file
2. Double-click `Northwen-BidWriter-Setup.exe`
3. If Windows shows security warning: "More info" → "Run anyway"
4. Follow setup wizard

### macOS
1. Extract ZIP file
2. Double-click `.dmg` file
3. Drag app to Applications folder
4. Right-click app → "Open" → "Open" (bypasses Gatekeeper)
5. Follow setup wizard

## Quick Demo Script (5 minutes)

1. **Launch app** → Complete setup wizard (choose "Local Models")
2. **Upload RFP** → Use included `sample_rfp.pdf`
3. **Watch analysis** → See compliance matrix populate
4. **Generate draft** → Click "Generate Draft" → Select sections
5. **Switch language** → Try French generation
6. **Export document** → PDF/DOCX with demo watermark
7. **Explore features** → Settings, models, templates

## Integrity Verification

Check file integrity with included checksums:

**Windows:**
```cmd
CertUtil -hashfile Northwen-BidWriter-Setup.exe SHA256
```

**macOS:**
```bash
shasum -a 256 Northwen-BidWriter.dmg
```

Compare with `checksums.txt`

## Full Version Benefits

- **Unlimited RFPs** and exports
- **No watermarks** on professional documents
- **Advanced templates** for all jurisdictions
- **Multi-user licenses** available
- **Priority support** and training
- **Custom branding** options
- **Cloud API integration** (OpenAI, Anthropic)

## Purchase Full Version

Ready to upgrade? Visit: https://northwen.com/bidwriter/purchase

Questions? Email: sales@northwen.com

---

**Turn RFPs into winning proposals - fast!** 🚀
DEMO_EOF

    print_success "Demo documentation created"
}

# Main execution
main() {
    print_status "Starting demo build process..."
    
    build_demo
    create_demo_bundle
    create_demo_docs
    
    echo ""
    print_success "🎉 Demo build complete!"
    echo ""
    echo "📦 Demo bundle: Northwen-BidWriter-Demo-$(date +%Y%m%d).zip"
    echo "📁 Contents: Installer + License + Sample RFP + Documentation"
    echo "🔒 Security: Unsigned (prospects will see one security prompt)"
    echo "⏰ Trial: 14 days, 3 RFPs max, demo watermarks"
    echo ""
    echo "Ready to share with prospects! 🎯"
}

main "$@"
