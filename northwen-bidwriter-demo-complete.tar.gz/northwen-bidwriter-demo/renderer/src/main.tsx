import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.tsx';
import './assets/themes/globals.css';

// Initialize the app store
import { useAppStore } from '@/lib/store';

// Initialize app on startup
const initializeApp = async () => {
  const store = useAppStore.getState();
  await store.initialize();
};

// Start the app
initializeApp().then(() => {
  ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>,
  );
});
