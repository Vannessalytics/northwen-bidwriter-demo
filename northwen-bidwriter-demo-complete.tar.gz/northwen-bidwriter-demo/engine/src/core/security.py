"""
Security utilities for Northwen BidWriter Engine.
"""

import hashlib
import hmac
import logging
import secrets
from typing import Optional

from fastapi import HTTPException, Request, status
from core.config import get_settings

logger = logging.getLogger(__name__)

def verify_shared_secret(request: Request) -> bool:
    """
    Verify the shared secret from the request header.
    
    Args:
        request: FastAPI request object
        
    Returns:
        bool: True if secret is valid
        
    Raises:
        HTTPException: If secret is missing or invalid
    """
    settings = get_settings()
    
    # Get secret from header
    provided_secret = request.headers.get("X-Engine-Secret")
    
    if not provided_secret:
        logger.warning(f"Missing shared secret from {request.client.host}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing authentication secret"
        )
    
    # Constant-time comparison to prevent timing attacks
    expected_secret = settings.shared_secret
    
    if not secrets.compare_digest(provided_secret, expected_secret):
        logger.warning(f"Invalid shared secret from {request.client.host}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication secret"
        )
    
    return True

def generate_file_hash(file_path: str, algorithm: str = "sha256") -> str:
    """
    Generate hash of a file.
    
    Args:
        file_path: Path to the file
        algorithm: Hash algorithm to use
        
    Returns:
        str: Hexadecimal hash string
    """
    hash_obj = hashlib.new(algorithm)
    
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_obj.update(chunk)
    
    return hash_obj.hexdigest()

def verify_file_integrity(file_path: str, expected_hash: str, algorithm: str = "sha256") -> bool:
    """
    Verify file integrity using hash comparison.
    
    Args:
        file_path: Path to the file
        expected_hash: Expected hash value
        algorithm: Hash algorithm to use
        
    Returns:
        bool: True if file integrity is verified
    """
    try:
        actual_hash = generate_file_hash(file_path, algorithm)
        return secrets.compare_digest(actual_hash.lower(), expected_hash.lower())
    except Exception as e:
        logger.error(f"Error verifying file integrity: {e}")
        return False

def sanitize_filename(filename: str) -> str:
    """
    Sanitize filename to prevent path traversal attacks.
    
    Args:
        filename: Original filename
        
    Returns:
        str: Sanitized filename
    """
    # Remove path components
    filename = filename.split("/")[-1].split("\\")[-1]
    
    # Remove or replace dangerous characters
    dangerous_chars = ['<', '>', ':', '"', '|', '?', '*', '\0']
    for char in dangerous_chars:
        filename = filename.replace(char, '_')
    
    # Limit length
    if len(filename) > 255:
        name, ext = filename.rsplit('.', 1) if '.' in filename else (filename, '')
        max_name_len = 255 - len(ext) - 1 if ext else 255
        filename = name[:max_name_len] + ('.' + ext if ext else '')
    
    # Ensure it's not empty or just dots
    if not filename or filename in ['.', '..']:
        filename = 'unnamed_file'
    
    return filename

def is_safe_path(base_path: str, target_path: str) -> bool:
    """
    Check if target path is within base path (prevent directory traversal).
    
    Args:
        base_path: Base directory path
        target_path: Target file path
        
    Returns:
        bool: True if path is safe
    """
    try:
        from pathlib import Path
        base = Path(base_path).resolve()
        target = Path(target_path).resolve()
        
        # Check if target is within base
        return str(target).startswith(str(base))
    except Exception:
        return False

class ContentFilter:
    """Content filtering for security and compliance."""
    
    # Patterns that should never appear in generated content
    FORBIDDEN_PATTERNS = [
        # Injection attempts
        r'<script[^>]*>.*?</script>',
        r'javascript:',
        r'vbscript:',
        r'onload\s*=',
        r'onerror\s*=',
        
        # SQL injection patterns
        r'union\s+select',
        r'drop\s+table',
        r'delete\s+from',
        
        # System commands
        r'rm\s+-rf',
        r'del\s+/[qsf]',
        r'format\s+c:',
    ]
    
    @classmethod
    def is_content_safe(cls, content: str) -> bool:
        """
        Check if content is safe for processing/display.
        
        Args:
            content: Content to check
            
        Returns:
            bool: True if content is safe
        """
        import re
        
        content_lower = content.lower()
        
        for pattern in cls.FORBIDDEN_PATTERNS:
            if re.search(pattern, content_lower, re.IGNORECASE | re.DOTALL):
                logger.warning(f"Unsafe content detected: {pattern}")
                return False
        
        return True
    
    @classmethod
    def sanitize_content(cls, content: str) -> str:
        """
        Sanitize content by removing potentially dangerous elements.
        
        Args:
            content: Content to sanitize
            
        Returns:
            str: Sanitized content
        """
        import re
        
        # Remove script tags and their content
        content = re.sub(r'<script[^>]*>.*?</script>', '', content, flags=re.IGNORECASE | re.DOTALL)
        
        # Remove javascript: and vbscript: URLs
        content = re.sub(r'(javascript|vbscript):[^"\s]*', '', content, flags=re.IGNORECASE)
        
        # Remove event handlers
        content = re.sub(r'on\w+\s*=\s*["\'][^"\']*["\']', '', content, flags=re.IGNORECASE)
        
        return content

def create_secure_temp_file(suffix: str = "", prefix: str = "nw_") -> str:
    """
    Create a secure temporary file.
    
    Args:
        suffix: File suffix
        prefix: File prefix
        
    Returns:
        str: Path to temporary file
    """
    import tempfile
    from core.config import get_settings
    
    settings = get_settings()
    
    # Create temporary file in our secure temp directory
    fd, path = tempfile.mkstemp(
        suffix=suffix,
        prefix=prefix,
        dir=str(settings.temp_dir)
    )
    
    # Close the file descriptor (we just need the path)
    import os
    os.close(fd)
    
    return path
