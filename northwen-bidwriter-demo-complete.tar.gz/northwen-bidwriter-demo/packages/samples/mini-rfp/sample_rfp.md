# Request for Proposal: IT Consulting Services
**RFP Number:** PSPC-2024-IT-001  
**Issue Date:** January 15, 2024  
**Closing Date:** February 15, 2024, 2:00 PM EST  
**Language:** English/French

## 1. Introduction

Public Services and Procurement Canada (PSPC) is seeking qualified IT consulting firms to provide comprehensive technology consulting services for a digital transformation initiative.

## 2. Scope of Work

The successful proponent will provide the following services:

### 2.1 Technical Assessment
- Conduct comprehensive assessment of current IT infrastructure
- Identify gaps and opportunities for improvement
- Develop modernization roadmap

### 2.2 Solution Design
- Design cloud migration strategy
- Develop security framework
- Create integration architecture

### 2.3 Implementation Support
- Provide project management oversight
- Support change management activities
- Deliver training programs

## 3. Mandatory Requirements

Bidders must meet ALL of the following mandatory requirements:

**M1.** Minimum 5 years experience in government IT consulting  
**M2.** Valid security clearance (Secret level or higher)  
**M3.** ISO 27001 certification  
**M4.** Minimum $2M professional liability insurance  
**M5.** Bilingual capability (English/French)

## 4. Rated Criteria

Proposals will be evaluated based on the following criteria:

### 4.1 Technical Approach (30 points)
- Quality and feasibility of proposed methodology
- Innovation and best practices
- Risk mitigation strategies

### 4.2 Team Qualifications (25 points)
- Relevant experience of key personnel
- Educational qualifications
- Professional certifications

### 4.3 Past Performance (20 points)
- Similar project experience
- Client references
- Project success metrics

### 4.4 Project Management (15 points)
- Project management methodology
- Quality assurance processes
- Communication plan

### 4.5 Value Proposition (10 points)
- Cost effectiveness
- Added value services
- Knowledge transfer approach

## 5. Proposal Requirements

### 5.1 Format Requirements
- Maximum 25 pages (excluding appendices)
- Arial 12-point font
- 1.15 line spacing
- 2.5cm margins on all sides

### 5.2 Required Sections
1. Executive Summary (2 pages maximum)
2. Technical Approach and Methodology (8 pages maximum)
3. Project Management Plan (5 pages maximum)
4. Team Qualifications and Experience (6 pages maximum)
5. Past Performance and References (4 pages maximum)

### 5.3 Appendices
- Resumes of key personnel
- Corporate profile and certifications
- Sample work products
- Client references

## 6. Evaluation Process

### 6.1 Mandatory Requirements
Proposals not meeting all mandatory requirements will be rejected.

### 6.2 Technical Evaluation
Proposals meeting mandatory requirements will be scored out of 100 points based on rated criteria.

### 6.3 Financial Evaluation
Financial proposals will be evaluated separately after technical evaluation.

## 7. Contract Terms

### 7.1 Contract Duration
- Initial term: 24 months
- Option periods: 2 x 12 months

### 7.2 Contract Value
- Estimated value: $500,000 - $750,000 CAD
- Payment terms: Net 30 days

### 7.3 Key Deliverables
- Current state assessment report
- Future state architecture design
- Implementation roadmap
- Training materials

## 8. Submission Requirements

### 8.1 Deadline
Proposals must be received by February 15, 2024, 2:00 PM EST.

### 8.2 Submission Method
Electronic submission via Government Electronic Tendering Service (GETS).

### 8.3 File Format
- PDF format preferred
- Maximum file size: 25MB
- File naming: CompanyName_PSPC-2024-IT-001_EN.pdf

## 9. Contact Information

**Contracting Authority:**  
Jane Smith, Senior Procurement Officer  
Public Services and Procurement Canada  
Email: jane.smith@pspc-spac.gc.ca  
Phone: (613) 555-0123

**Technical Authority:**  
John Doe, IT Director  
Email: john.doe@pspc-spac.gc.ca  
Phone: (613) 555-0124

## 10. Terms and Conditions

This RFP is subject to the standard terms and conditions of PSPC. Bidders are expected to be familiar with Government of Canada procurement policies and procedures.

### 10.1 Conflict of Interest
Bidders must declare any potential conflicts of interest.

### 10.2 Security Requirements
All personnel must obtain appropriate security clearances before commencing work.

### 10.3 Official Languages
Services must be available in both English and French as required.

---

**End of RFP Document**

*This is a sample RFP for demonstration purposes only.*
