import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
  createdAt: string;
}

export interface RFP {
  id: string;
  name: string;
  fileName: string;
  filePath: string;
  uploadedAt: string;
  status: 'processing' | 'ready' | 'error';
  language: 'en' | 'fr' | 'both';
  deadlines: Array<{
    type: string;
    date: string;
    description: string;
  }>;
  requirements: Array<{
    id: string;
    type: 'mandatory' | 'rated' | 'informational';
    description: string;
    status: 'met' | 'partial' | 'missing' | 'na';
    section?: string;
    notes?: string;
  }>;
  riskScore: number;
  complianceScore: number;
}

export interface Draft {
  id: string;
  rfpId: string;
  name: string;
  language: 'en' | 'fr';
  sections: Record<string, {
    content: string;
    wordCount: number;
    lastModified: string;
    version: number;
  }>;
  createdAt: string;
  updatedAt: string;
}

export interface AppSettings {
  language: 'en' | 'fr' | 'both';
  theme: 'light' | 'dark' | 'system';
  modelMode: 'local' | 'cloud' | 'ollama';
  cloudApiKeys: {
    openai?: string;
    anthropic?: string;
  };
  boilerplate: {
    en: Record<string, string>;
    fr: Record<string, string>;
  };
  templates: Array<{
    id: string;
    name: string;
    type: 'canada-buys' | 'sam-gov' | 'custom';
    path: string;
  }>;
  backupSettings: {
    autoBackup: boolean;
    retentionDays: number;
    location: string;
  };
  telemetryEnabled: boolean;
}

export interface AppState {
  // App lifecycle
  isFirstRun: boolean;
  isLoading: boolean;
  isInitialized: boolean;
  
  // User & auth
  currentUser: User | null;
  
  // Data
  rfps: RFP[];
  drafts: Draft[];
  
  // Settings
  settings: AppSettings;
  
  // UI state
  sidebarCollapsed: boolean;
  currentRfpId: string | null;
  currentDraftId: string | null;
  
  // Engine status
  engineStatus: 'connecting' | 'connected' | 'error';
  engineConfig: {
    port: number;
    secret: string;
    baseUrl: string;
  } | null;
}

export interface AppActions {
  // Initialization
  initialize: () => Promise<void>;
  completeFirstRun: () => void;
  
  // User management
  setCurrentUser: (user: User) => void;
  
  // RFP management
  addRfp: (rfp: RFP) => void;
  updateRfp: (id: string, updates: Partial<RFP>) => void;
  removeRfp: (id: string) => void;
  setCurrentRfp: (id: string | null) => void;
  
  // Draft management
  addDraft: (draft: Draft) => void;
  updateDraft: (id: string, updates: Partial<Draft>) => void;
  removeDraft: (id: string) => void;
  setCurrentDraft: (id: string | null) => void;
  
  // Settings
  updateSettings: (updates: Partial<AppSettings>) => void;
  
  // UI state
  toggleSidebar: () => void;
  setSidebarCollapsed: (collapsed: boolean) => void;
  
  // Engine
  setEngineStatus: (status: AppState['engineStatus']) => void;
  setEngineConfig: (config: AppState['engineConfig']) => void;
}

const defaultSettings: AppSettings = {
  language: 'en',
  theme: 'light',
  modelMode: 'local',
  cloudApiKeys: {},
  boilerplate: {
    en: {},
    fr: {}
  },
  templates: [],
  backupSettings: {
    autoBackup: true,
    retentionDays: 30,
    location: ''
  },
  telemetryEnabled: false
};

export const useAppStore = create<AppState & AppActions>()(
  persist(
    immer((set, get) => ({
      // Initial state
      isFirstRun: true,
      isLoading: true,
      isInitialized: false,
      currentUser: null,
      rfps: [],
      drafts: [],
      settings: defaultSettings,
      sidebarCollapsed: false,
      currentRfpId: null,
      currentDraftId: null,
      engineStatus: 'connecting',
      engineConfig: null,

      // Actions
      initialize: async () => {
        set((state) => {
          state.isLoading = true;
        });

        try {
          // Check if this is first run
          const hasUser = get().currentUser !== null;
          const hasSettings = Object.keys(get().settings.boilerplate.en).length > 0;
          
          if (!hasUser || !hasSettings) {
            set((state) => {
              state.isFirstRun = true;
              state.isLoading = false;
            });
            return;
          }

          // Initialize engine connection
          if (window.electronAPI) {
            const engineConfig = await window.electronAPI.getEngineConfig();
            set((state) => {
              state.engineConfig = engineConfig;
              state.engineStatus = 'connected';
            });
          }

          set((state) => {
            state.isFirstRun = false;
            state.isInitialized = true;
            state.isLoading = false;
          });
        } catch (error) {
          console.error('Failed to initialize app:', error);
          set((state) => {
            state.engineStatus = 'error';
            state.isLoading = false;
          });
        }
      },

      completeFirstRun: () => {
        set((state) => {
          state.isFirstRun = false;
          state.isInitialized = true;
        });
      },

      setCurrentUser: (user) => {
        set((state) => {
          state.currentUser = user;
        });
      },

      addRfp: (rfp) => {
        set((state) => {
          state.rfps.push(rfp);
        });
      },

      updateRfp: (id, updates) => {
        set((state) => {
          const index = state.rfps.findIndex(rfp => rfp.id === id);
          if (index !== -1) {
            Object.assign(state.rfps[index], updates);
          }
        });
      },

      removeRfp: (id) => {
        set((state) => {
          state.rfps = state.rfps.filter(rfp => rfp.id !== id);
          if (state.currentRfpId === id) {
            state.currentRfpId = null;
          }
        });
      },

      setCurrentRfp: (id) => {
        set((state) => {
          state.currentRfpId = id;
        });
      },

      addDraft: (draft) => {
        set((state) => {
          state.drafts.push(draft);
        });
      },

      updateDraft: (id, updates) => {
        set((state) => {
          const index = state.drafts.findIndex(draft => draft.id === id);
          if (index !== -1) {
            Object.assign(state.drafts[index], updates);
          }
        });
      },

      removeDraft: (id) => {
        set((state) => {
          state.drafts = state.drafts.filter(draft => draft.id !== id);
          if (state.currentDraftId === id) {
            state.currentDraftId = null;
          }
        });
      },

      setCurrentDraft: (id) => {
        set((state) => {
          state.currentDraftId = id;
        });
      },

      updateSettings: (updates) => {
        set((state) => {
          Object.assign(state.settings, updates);
        });
      },

      toggleSidebar: () => {
        set((state) => {
          state.sidebarCollapsed = !state.sidebarCollapsed;
        });
      },

      setSidebarCollapsed: (collapsed) => {
        set((state) => {
          state.sidebarCollapsed = collapsed;
        });
      },

      setEngineStatus: (status) => {
        set((state) => {
          state.engineStatus = status;
        });
      },

      setEngineConfig: (config) => {
        set((state) => {
          state.engineConfig = config;
        });
      },
    })),
    {
      name: 'northwen-bidwriter-store',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        // Only persist certain parts of the state
        currentUser: state.currentUser,
        settings: state.settings,
        sidebarCollapsed: state.sidebarCollapsed,
        isFirstRun: state.isFirstRun,
      }),
    }
  )
);
