# 🎯 Northwen BidWriter Demo

**FREE 14-Day Trial** - Turn government RFPs into compliant bid drafts fast!

## 🚀 Quick Demo Download

**Ready-to-run demo installers** (no code signing certificates needed):

### Windows Users:
1. Download `Northwen-BidWriter-Demo-Setup.exe`
2. Double-click installer
3. If Windows shows "Windows protected your PC": Click **"More info"** → **"Run anyway"**
4. Complete setup wizard (choose "Local Models" for offline demo)

### macOS Users:
1. Download `Northwen-BidWriter-Demo.dmg`
2. Double-click DMG → Drag app to Applications
3. If macOS blocks: Right-click app → **"Open"** → **"Open"**
4. Complete setup wizard (choose "Local Models" for offline demo)

## ⚡ 5-Minute Demo Script

1. **Upload Sample RFP** → Use included `sample_rfp.pdf`
2. **Watch AI Analysis** → See compliance matrix populate automatically
3. **Generate Draft** → AI creates proposal sections
4. **Switch to French** → Test bilingual capabilities
5. **Export PDF/DOCX** → Professional formatting (with demo watermark)
6. **Go Offline** → Disconnect WiFi - app still works!

## ✨ Demo Features

- ✅ **Full AI-powered RFP analysis**
- ✅ **Bilingual proposal generation** (EN/FR-CA)
- ✅ **Professional DOCX/PDF export**
- ✅ **Offline-first operation** (no internet required)
- ✅ **Antivirus scanning and security**
- ✅ **Local AI models** (privacy-first)

## 🔒 Demo Limitations

- **14-day trial period**
- **Maximum 3 RFPs** can be processed
- **Demo watermarks** on all exports
- **Basic templates only** (advanced templates in full version)

## 🏗️ For Developers

### Build Demo Installers

```bash
# Install dependencies
npm install
cd renderer && npm install && cd ..
cd engine && pip install -r requirements.txt && cd ..

# Build unsigned demo installers
npm run build:demo

# Platform-specific builds
npm run package:win  # Windows
npm run package:mac  # macOS
```

### Demo Configuration

- **License**: `demo-bundle/license-demo.nwlic` (14-day expiration)
- **Sample RFP**: `demo-bundle/sample_rfp.pdf`
- **Models**: Optimized 2GB models for fast download
- **Watermarks**: Enabled on all exports

## 🎯 Full Version Benefits

- **Unlimited RFPs** and exports
- **No watermarks** on professional documents
- **Advanced templates** for all jurisdictions
- **Multi-user licenses** available
- **Priority support** and training
- **Custom branding** options
- **Cloud API integration** (OpenAI, Anthropic)

## 📞 Ready to Upgrade?

**Purchase Full Version**: https://northwen.com/bidwriter/purchase
**Questions?** Email: sales@northwen.com

---

**Turn RFPs into winning proposals - fast!** 🚀

*This is a demo repository. For the full production version, see: [northwen-bidwriter](https://github.com/Vannessalytics/northwen-bidwriter)*
