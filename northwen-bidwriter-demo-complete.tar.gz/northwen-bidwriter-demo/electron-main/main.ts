import { app, BrowserWindow, ipcMain, dialog, shell } from 'electron';
import { autoUpdater } from 'electron-updater';
import * as path from 'path';
import * as fs from 'fs';
import { spawn, ChildProcess } from 'child_process';
import * as crypto from 'crypto';

// Security: Generate shared secret for engine communication
const SHARED_SECRET = crypto.randomBytes(32).toString('hex');
const ENGINE_PORT = 8127;

let mainWindow: BrowserWindow | null = null;
let engineProcess: ChildProcess | null = null;

// Configure auto-updater (disabled by default)
autoUpdater.autoDownload = false;
autoUpdater.autoInstallOnAppQuit = false;

class EngineManager {
  private enginePath: string;
  
  constructor() {
    const isDev = process.env.NODE_ENV === 'development';
    this.enginePath = isDev 
      ? path.join(__dirname, '../../engine/dist/engine')
      : path.join(process.resourcesPath, 'engine/engine');
    
    if (process.platform === 'win32') {
      this.enginePath += '.exe';
    }
  }

  async start(): Promise<boolean> {
    return new Promise((resolve) => {
      if (!fs.existsSync(this.enginePath)) {
        console.error('Engine binary not found:', this.enginePath);
        resolve(false);
        return;
      }

      engineProcess = spawn(this.enginePath, [
        '--port', ENGINE_PORT.toString(),
        '--secret', SHARED_SECRET,
        '--host', '127.0.0.1'
      ], {
        stdio: ['ignore', 'pipe', 'pipe']
      });

      engineProcess.stdout?.on('data', (data) => {
        console.log('Engine:', data.toString());
      });

      engineProcess.stderr?.on('data', (data) => {
        console.error('Engine Error:', data.toString());
      });

      engineProcess.on('close', (code) => {
        console.log('Engine process exited with code:', code);
        engineProcess = null;
      });

      // Wait for engine to be ready
      setTimeout(() => resolve(true), 3000);
    });
  }

  stop(): void {
    if (engineProcess) {
      engineProcess.kill();
      engineProcess = null;
    }
  }
}

const engineManager = new EngineManager();

function createWindow(): void {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1200,
    minHeight: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      enableRemoteModule: false,
      preload: path.join(__dirname, 'preload.js'),
      webSecurity: true,
      allowRunningInsecureContent: false,
      experimentalFeatures: false
    },
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    show: false,
    icon: path.join(__dirname, '../assets/icons/icon.png')
  });

  // Security: Set CSP
  mainWindow.webContents.session.webRequest.onHeadersReceived((details, callback) => {
    callback({
      responseHeaders: {
        ...details.responseHeaders,
        'Content-Security-Policy': [
          "default-src 'self'; " +
          "script-src 'self' 'unsafe-inline'; " +
          "style-src 'self' 'unsafe-inline'; " +
          "img-src 'self' data: blob:; " +
          "font-src 'self' data:; " +
          "connect-src 'self' http://127.0.0.1:8127; " +
          "object-src 'none'; " +
          "base-uri 'self';"
        ]
      }
    });
  });

  const isDev = process.env.NODE_ENV === 'development';
  
  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, '../renderer/dist/index.html'));
  }

  mainWindow.once('ready-to-show', () => {
    mainWindow?.show();
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // Security: Prevent new window creation
  mainWindow.webContents.setWindowOpenHandler(() => {
    return { action: 'deny' };
  });

  // Security: Handle external links
  mainWindow.webContents.on('will-navigate', (event, navigationUrl) => {
    const parsedUrl = new URL(navigationUrl);
    
    if (parsedUrl.origin !== 'http://localhost:5173' && !isDev) {
      event.preventDefault();
    }
  });
}

// App event handlers
app.whenReady().then(async () => {
  await engineManager.start();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  engineManager.stop();
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('before-quit', () => {
  engineManager.stop();
});

// IPC handlers
ipcMain.handle('get-engine-config', () => {
  return {
    port: ENGINE_PORT,
    secret: SHARED_SECRET,
    baseUrl: `http://127.0.0.1:${ENGINE_PORT}`
  };
});

ipcMain.handle('show-save-dialog', async (_, options) => {
  if (!mainWindow) return { canceled: true };
  
  return await dialog.showSaveDialog(mainWindow, options);
});

ipcMain.handle('show-open-dialog', async (_, options) => {
  if (!mainWindow) return { canceled: true };
  
  return await dialog.showOpenDialog(mainWindow, options);
});

ipcMain.handle('show-message-box', async (_, options) => {
  if (!mainWindow) return { response: 0 };
  
  return await dialog.showMessageBox(mainWindow, options);
});

ipcMain.handle('open-external', async (_, url: string) => {
  await shell.openExternal(url);
});

ipcMain.handle('show-item-in-folder', (_, fullPath: string) => {
  shell.showItemInFolder(fullPath);
});

ipcMain.handle('get-app-version', () => {
  return app.getVersion();
});

ipcMain.handle('get-app-path', (_, name: string) => {
  return app.getPath(name as any);
});

// Auto-updater events (disabled by default)
autoUpdater.on('checking-for-update', () => {
  console.log('Checking for update...');
});

autoUpdater.on('update-available', (info) => {
  console.log('Update available:', info);
});

autoUpdater.on('update-not-available', (info) => {
  console.log('Update not available:', info);
});

autoUpdater.on('error', (err) => {
  console.log('Error in auto-updater:', err);
});

export { SHARED_SECRET, ENGINE_PORT };
