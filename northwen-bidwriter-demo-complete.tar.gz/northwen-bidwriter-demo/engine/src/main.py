#!/usr/bin/env python3
"""
Northwen BidWriter Engine
Main application entry point for the local Python API server.
"""

import argparse
import asyncio
import logging
import os
import sys
from pathlib import Path

import uvicorn
from fastapi import FastAPI, HTTPException, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager

from core.config import get_settings
from core.security import verify_shared_secret
from core.database import init_database
from core.logging_config import setup_logging
from api.routes import health, rfp, draft, models, settings, backup, diagnostics

# Setup logging
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager."""
    # Startup
    logger.info("Starting Northwen BidWriter Engine")
    
    # Initialize database
    await init_database()
    
    # Initialize AI models if configured
    from core.ai_manager import AIManager
    ai_manager = AIManager()
    await ai_manager.initialize()
    
    # Store in app state
    app.state.ai_manager = ai_manager
    
    logger.info("Engine startup complete")
    
    yield
    
    # Shutdown
    logger.info("Shutting down Northwen BidWriter Engine")
    if hasattr(app.state, 'ai_manager'):
        await app.state.ai_manager.cleanup()

def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    settings = get_settings()
    
    app = FastAPI(
        title="Northwen BidWriter Engine",
        description="Local API server for RFP processing and AI-powered bid writing",
        version="1.0.0",
        docs_url=None,  # Disable docs in production
        redoc_url=None,  # Disable redoc in production
        lifespan=lifespan
    )
    
    # Security middleware
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=["127.0.0.1", "localhost"]
    )
    
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://127.0.0.1:*", "http://localhost:*"],
        allow_credentials=False,
        allow_methods=["GET", "POST", "PUT", "DELETE"],
        allow_headers=["*"],
    )
    
    # Global exception handler
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        logger.error(f"Unhandled exception: {exc}", exc_info=True)
        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "error": "Internal server error",
                "message": "An unexpected error occurred"
            }
        )
    
    # Security dependency for all routes except health
    async def verify_request_security(request: Request):
        if request.url.path == "/health":
            return True
        return verify_shared_secret(request)
    
    # Include routers with security dependency
    app.include_router(health.router, tags=["health"])
    app.include_router(
        rfp.router, 
        prefix="/rfp", 
        tags=["rfp"],
        dependencies=[Depends(verify_request_security)]
    )
    app.include_router(
        draft.router, 
        prefix="/draft", 
        tags=["draft"],
        dependencies=[Depends(verify_request_security)]
    )
    app.include_router(
        models.router, 
        prefix="/models", 
        tags=["models"],
        dependencies=[Depends(verify_request_security)]
    )
    app.include_router(
        settings.router, 
        prefix="/settings", 
        tags=["settings"],
        dependencies=[Depends(verify_request_security)]
    )
    app.include_router(
        backup.router, 
        prefix="/backup", 
        tags=["backup"],
        dependencies=[Depends(verify_request_security)]
    )
    app.include_router(
        diagnostics.router, 
        prefix="/diagnostics", 
        tags=["diagnostics"],
        dependencies=[Depends(verify_request_security)]
    )
    
    return app

def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Northwen BidWriter Engine")
    parser.add_argument("--host", default="127.0.0.1", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8127, help="Port to bind to")
    parser.add_argument("--secret", required=True, help="Shared secret for authentication")
    parser.add_argument("--log-level", default="INFO", help="Logging level")
    parser.add_argument("--data-dir", help="Data directory path")
    
    args = parser.parse_args()
    
    # Setup logging
    setup_logging(args.log_level)
    
    # Set environment variables
    os.environ["ENGINE_HOST"] = args.host
    os.environ["ENGINE_PORT"] = str(args.port)
    os.environ["SHARED_SECRET"] = args.secret
    
    if args.data_dir:
        os.environ["DATA_DIR"] = args.data_dir
    
    # Create app
    app = create_app()
    
    # Configure uvicorn
    config = uvicorn.Config(
        app,
        host=args.host,
        port=args.port,
        log_level=args.log_level.lower(),
        access_log=False,  # We handle our own logging
        server_header=False,
        date_header=False,
    )
    
    # Run server
    server = uvicorn.Server(config)
    
    try:
        logger.info(f"Starting server on {args.host}:{args.port}")
        asyncio.run(server.serve())
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
    except Exception as e:
        logger.error(f"Server error: {e}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main()
