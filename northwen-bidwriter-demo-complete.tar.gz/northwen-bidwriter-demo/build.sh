#!/bin/bash
# Northwen BidWriter Build Script
# Builds the complete application for distribution

set -e  # Exit on any error

echo "🚀 Building Northwen BidWriter..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check prerequisites
check_prerequisites() {
    print_status "Checking prerequisites..."
    
    # Check Node.js
    if ! command -v node &> /dev/null; then
        print_error "Node.js is not installed"
        exit 1
    fi
    
    # Check Python
    if ! command -v python3 &> /dev/null; then
        print_error "Python 3 is not installed"
        exit 1
    fi
    
    # Check npm
    if ! command -v npm &> /dev/null; then
        print_error "npm is not installed"
        exit 1
    fi
    
    print_success "Prerequisites check passed"
}

# Install dependencies
install_dependencies() {
    print_status "Installing dependencies..."
    
    # Root dependencies
    npm install
    
    # Renderer dependencies
    cd renderer
    npm install
    cd ..
    
    # Python dependencies
    cd engine
    pip3 install -r requirements.txt
    cd ..
    
    print_success "Dependencies installed"
}

# Build renderer
build_renderer() {
    print_status "Building renderer..."
    
    cd renderer
    npm run build
    cd ..
    
    print_success "Renderer built"
}

# Build Electron main process
build_electron() {
    print_status "Building Electron main process..."
    
    npm run build:electron
    
    print_success "Electron main process built"
}

# Build Python engine
build_engine() {
    print_status "Building Python engine..."
    
    cd engine
    
    # Create virtual environment for clean build
    python3 -m venv build_env
    source build_env/bin/activate || source build_env/Scripts/activate  # Windows compatibility
    
    # Install dependencies in clean environment
    pip install -r requirements.txt
    pip install pyinstaller
    
    # Build with PyInstaller
    pyinstaller engine.spec --clean --noconfirm
    
    # Deactivate virtual environment
    deactivate
    
    # Clean up
    rm -rf build_env
    
    cd ..
    
    print_success "Python engine built"
}

# Package application
package_app() {
    print_status "Packaging application..."
    
    # Determine platform
    if [[ "$OSTYPE" == "darwin"* ]]; then
        npm run package:mac
        print_success "macOS package created"
    elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]]; then
        npm run package:win
        print_success "Windows package created"
    else
        npm run package
        print_success "Package created"
    fi
}

# Run tests
run_tests() {
    print_status "Running tests..."
    
    # Unit tests
    npm run test:unit
    
    # E2E tests (skip in CI for now)
    if [[ -z "$CI" ]]; then
        print_warning "Skipping E2E tests (not in CI environment)"
        # npm run test:e2e
    fi
    
    print_success "Tests completed"
}

# Clean build artifacts
clean() {
    print_status "Cleaning build artifacts..."
    
    rm -rf dist/
    rm -rf dist-packages/
    rm -rf renderer/dist/
    rm -rf engine/dist/
    rm -rf engine/build/
    
    print_success "Build artifacts cleaned"
}

# Main build process
main() {
    echo "🏗️  Northwen BidWriter Build Process"
    echo "=================================="
    
    # Parse command line arguments
    case "${1:-all}" in
        "clean")
            clean
            ;;
        "deps")
            check_prerequisites
            install_dependencies
            ;;
        "renderer")
            build_renderer
            ;;
        "electron")
            build_electron
            ;;
        "engine")
            build_engine
            ;;
        "package")
            package_app
            ;;
        "test")
            run_tests
            ;;
        "all")
            check_prerequisites
            install_dependencies
            build_renderer
            build_electron
            build_engine
            run_tests
            package_app
            ;;
        *)
            echo "Usage: $0 [clean|deps|renderer|electron|engine|package|test|all]"
            echo ""
            echo "Commands:"
            echo "  clean     - Clean build artifacts"
            echo "  deps      - Install dependencies"
            echo "  renderer  - Build renderer only"
            echo "  electron  - Build Electron main process only"
            echo "  engine    - Build Python engine only"
            echo "  package   - Package application"
            echo "  test      - Run tests"
            echo "  all       - Full build process (default)"
            exit 1
            ;;
    esac
    
    print_success "Build process completed! 🎉"
    
    # Show output location
    if [[ -d "dist-packages" ]]; then
        echo ""
        echo "📦 Packages created in: dist-packages/"
        ls -la dist-packages/
    fi
}

# Run main function with all arguments
main "$@"
