import { test, expect } from '@playwright/test';

test.describe('First Run Wizard', () => {
  test.beforeEach(async ({ page }) => {
    // Clear any existing data
    await page.evaluate(() => {
      localStorage.clear();
      sessionStorage.clear();
    });
  });

  test('should complete first run wizard successfully', async ({ page }) => {
    await page.goto('/');

    // Should show first run wizard
    await expect(page.locator('h1')).toContainText('Welcome to Northwen BidWriter');

    // Step 1: Welcome
    await page.click('button:has-text("Get Started")');

    // Step 2: License (use trial mode)
    await expect(page.locator('h2')).toContainText('License Agreement');
    await page.click('button:has-text("Start Trial")');

    // Step 3: Admin setup
    await expect(page.locator('h2')).toContainText('Administrator Setup');
    await page.fill('input[name="name"]', 'Test Admin');
    await page.fill('input[name="email"]', 'admin@test.com');
    await page.fill('input[name="password"]', 'TestPassword123!');
    await page.fill('input[name="confirmPassword"]', 'TestPassword123!');
    await page.click('button:has-text("Next")');

    // Step 4: Language preferences
    await expect(page.locator('h2')).toContainText('Language Preferences');
    await page.click('input[value="en"]'); // English only for testing
    await page.click('button:has-text("Next")');

    // Step 5: Model configuration
    await expect(page.locator('h2')).toContainText('AI Model Configuration');
    await page.click('button:has-text("Use Local Models")');

    // Step 6: Model download (skip for testing)
    await expect(page.locator('h2')).toContainText('Model Download');
    await page.click('button:has-text("Skip for Now")');

    // Step 7: Complete
    await expect(page.locator('h2')).toContainText('Setup Complete');
    await page.click('button:has-text("Launch Application")');

    // Should redirect to dashboard
    await expect(page.locator('h1')).toContainText('Dashboard');
    await expect(page.url()).toContain('/dashboard');
  });

  test('should validate required fields in admin setup', async ({ page }) => {
    await page.goto('/');
    
    // Navigate to admin setup
    await page.click('button:has-text("Get Started")');
    await page.click('button:has-text("Start Trial")');

    // Try to proceed without filling fields
    await page.click('button:has-text("Next")');

    // Should show validation errors
    await expect(page.locator('text=Name is required')).toBeVisible();
    await expect(page.locator('text=Email is required')).toBeVisible();
    await expect(page.locator('text=Password is required')).toBeVisible();
  });

  test('should validate password confirmation', async ({ page }) => {
    await page.goto('/');
    
    // Navigate to admin setup
    await page.click('button:has-text("Get Started")');
    await page.click('button:has-text("Start Trial")');

    // Fill fields with mismatched passwords
    await page.fill('input[name="name"]', 'Test Admin');
    await page.fill('input[name="email"]', 'admin@test.com');
    await page.fill('input[name="password"]', 'TestPassword123!');
    await page.fill('input[name="confirmPassword"]', 'DifferentPassword123!');
    await page.click('button:has-text("Next")');

    // Should show password mismatch error
    await expect(page.locator('text=Passwords do not match')).toBeVisible();
  });

  test('should allow going back to previous steps', async ({ page }) => {
    await page.goto('/');
    
    // Navigate through several steps
    await page.click('button:has-text("Get Started")');
    await page.click('button:has-text("Start Trial")');
    
    await page.fill('input[name="name"]', 'Test Admin');
    await page.fill('input[name="email"]', 'admin@test.com');
    await page.fill('input[name="password"]', 'TestPassword123!');
    await page.fill('input[name="confirmPassword"]', 'TestPassword123!');
    await page.click('button:has-text("Next")');
    
    await page.click('input[value="en"]');
    await page.click('button:has-text("Next")');

    // Should be on model configuration step
    await expect(page.locator('h2')).toContainText('AI Model Configuration');

    // Go back to language step
    await page.click('button:has-text("Previous")');
    await expect(page.locator('h2')).toContainText('Language Preferences');

    // Go back to admin setup
    await page.click('button:has-text("Previous")');
    await expect(page.locator('h2')).toContainText('Administrator Setup');

    // Form should retain values
    await expect(page.locator('input[name="name"]')).toHaveValue('Test Admin');
    await expect(page.locator('input[name="email"]')).toHaveValue('admin@test.com');
  });
});
