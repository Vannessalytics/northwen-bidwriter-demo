import { useAppStore } from './store';

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface UploadProgress {
  stage: 'uploading' | 'scanning' | 'parsing' | 'indexing' | 'complete';
  progress: number;
  message: string;
}

export interface ComplianceRequirement {
  id: string;
  type: 'mandatory' | 'rated' | 'informational';
  description: string;
  section?: string;
  pageNumber?: number;
  status: 'met' | 'partial' | 'missing' | 'na';
  notes?: string;
  confidence: number;
}

export interface RiskAssessment {
  overallScore: number;
  categories: Array<{
    name: string;
    score: number;
    issues: string[];
    recommendations: string[];
  }>;
  criticalIssues: string[];
  warnings: string[];
}

export interface DraftSection {
  id: string;
  title: string;
  content: string;
  wordCount: number;
  requirements: string[];
  sources: Array<{
    type: 'rfp' | 'boilerplate' | 'past_performance';
    reference: string;
    confidence: number;
  }>;
  missingInfo: string[];
}

class ApiClient {
  private baseUrl: string = '';
  private secret: string = '';
  private initialized: boolean = false;

  async initialize(): Promise<void> {
    if (this.initialized) return;

    try {
      const config = await window.electronAPI?.getEngineConfig();
      if (config) {
        this.baseUrl = config.baseUrl;
        this.secret = config.secret;
        this.initialized = true;
      } else {
        throw new Error('Failed to get engine configuration');
      }
    } catch (error) {
      console.error('Failed to initialize API client:', error);
      useAppStore.getState().setEngineStatus('error');
      throw error;
    }
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    if (!this.initialized) {
      await this.initialize();
    }

    const url = `${this.baseUrl}${endpoint}`;
    const headers = {
      'Content-Type': 'application/json',
      'X-Engine-Secret': this.secret,
      ...options.headers,
    };

    try {
      const response = await fetch(url, {
        ...options,
        headers,
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error(`API request failed: ${endpoint}`, error);
      
      // Update engine status on connection errors
      if (error instanceof TypeError && error.message.includes('fetch')) {
        useAppStore.getState().setEngineStatus('error');
      }
      
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  // Health check
  async ping(): Promise<ApiResponse<{ status: string; version: string }>> {
    return this.request('/health');
  }

  // File upload and processing
  async uploadRfp(
    file: File,
    options: {
      language?: 'en' | 'fr' | 'both';
      onProgress?: (progress: UploadProgress) => void;
    } = {}
  ): Promise<ApiResponse<{ rfpId: string }>> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('language', options.language || 'en');

    // For file uploads, we don't use JSON content type
    const headers = {
      'X-Engine-Secret': this.secret,
    };

    try {
      const response = await fetch(`${this.baseUrl}/rfp/upload`, {
        method: 'POST',
        headers,
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      // Handle streaming progress updates if supported
      if (options.onProgress && response.body) {
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';

          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const progressData = JSON.parse(line.slice(6));
                options.onProgress(progressData);
              } catch (e) {
                // Ignore malformed progress data
              }
            }
          }
        }
      }

      const data = await response.json();
      return data;
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Upload failed',
      };
    }
  }

  // RFP analysis
  async analyzeRfp(rfpId: string): Promise<ApiResponse<{
    requirements: ComplianceRequirement[];
    riskAssessment: RiskAssessment;
    metadata: {
      pageCount: number;
      wordCount: number;
      language: string;
      deadlines: Array<{
        type: string;
        date: string;
        description: string;
      }>;
    };
  }>> {
    return this.request(`/rfp/${rfpId}/analyze`);
  }

  // Draft generation
  async generateDraft(
    rfpId: string,
    options: {
      language: 'en' | 'fr';
      sections: string[];
      template?: string;
      customInstructions?: string;
    }
  ): Promise<ApiResponse<{ draftId: string }>> {
    return this.request(`/rfp/${rfpId}/generate-draft`, {
      method: 'POST',
      body: JSON.stringify(options),
    });
  }

  // Get draft content
  async getDraft(draftId: string): Promise<ApiResponse<{
    sections: Record<string, DraftSection>;
    metadata: {
      language: string;
      totalWordCount: number;
      createdAt: string;
      updatedAt: string;
    };
  }>> {
    return this.request(`/draft/${draftId}`);
  }

  // Regenerate draft section
  async regenerateSection(
    draftId: string,
    sectionId: string,
    options: {
      instructions?: string;
      tone?: 'professional' | 'technical' | 'persuasive';
      length?: 'shorter' | 'longer' | 'same';
    } = {}
  ): Promise<ApiResponse<DraftSection>> {
    return this.request(`/draft/${draftId}/section/${sectionId}/regenerate`, {
      method: 'POST',
      body: JSON.stringify(options),
    });
  }

  // Export draft
  async exportDraft(
    draftId: string,
    options: {
      format: 'docx' | 'pdf';
      language: 'en' | 'fr' | 'both';
      template?: string;
      includeAttachments?: boolean;
    }
  ): Promise<ApiResponse<{
    files: Array<{
      name: string;
      path: string;
      language: string;
      format: string;
    }>;
  }>> {
    return this.request(`/draft/${draftId}/export`, {
      method: 'POST',
      body: JSON.stringify(options),
    });
  }

  // Model management
  async getAvailableModels(): Promise<ApiResponse<Array<{
    id: string;
    name: string;
    description: string;
    size: string;
    ramRequirement: string;
    downloadUrl: string;
    checksum: string;
    installed: boolean;
  }>>> {
    return this.request('/models/available');
  }

  async downloadModel(
    modelId: string,
    onProgress?: (progress: { percent: number; speed: string; eta: string }) => void
  ): Promise<ApiResponse<{ success: boolean }>> {
    // Implementation would handle streaming download with progress
    return this.request(`/models/${modelId}/download`, {
      method: 'POST',
    });
  }

  async removeModel(modelId: string): Promise<ApiResponse<{ success: boolean }>> {
    return this.request(`/models/${modelId}`, {
      method: 'DELETE',
    });
  }

  // Settings and configuration
  async updateSettings(settings: Record<string, any>): Promise<ApiResponse<{ success: boolean }>> {
    return this.request('/settings', {
      method: 'PUT',
      body: JSON.stringify(settings),
    });
  }

  async getSystemInfo(): Promise<ApiResponse<{
    version: string;
    platform: string;
    memory: {
      total: string;
      available: string;
      used: string;
    };
    disk: {
      total: string;
      available: string;
    };
    models: {
      active: string;
      loaded: string[];
    };
  }>> {
    return this.request('/system/info');
  }

  // Backup and restore
  async createBackup(): Promise<ApiResponse<{
    backupId: string;
    path: string;
    size: string;
  }>> {
    return this.request('/backup/create', {
      method: 'POST',
    });
  }

  async restoreBackup(backupPath: string): Promise<ApiResponse<{ success: boolean }>> {
    return this.request('/backup/restore', {
      method: 'POST',
      body: JSON.stringify({ path: backupPath }),
    });
  }

  // Diagnostics
  async generateDiagnostics(): Promise<ApiResponse<{
    bundlePath: string;
    size: string;
  }>> {
    return this.request('/diagnostics/generate', {
      method: 'POST',
    });
  }
}

// Create singleton instance
export const apiClient = new ApiClient();

// React Query keys for caching
export const queryKeys = {
  rfps: ['rfps'] as const,
  rfp: (id: string) => ['rfp', id] as const,
  rfpAnalysis: (id: string) => ['rfp', id, 'analysis'] as const,
  draft: (id: string) => ['draft', id] as const,
  models: ['models'] as const,
  systemInfo: ['system', 'info'] as const,
} as const;
