"""
Configuration management for Northwen BidWriter Engine.
"""

import os
from pathlib import Path
from typing import Optional
from functools import lru_cache

from pydantic import BaseSettings, Field


class Settings(BaseSettings):
    """Application settings."""
    
    # Server configuration
    host: str = Field(default="127.0.0.1", env="ENGINE_HOST")
    port: int = Field(default=8127, env="ENGINE_PORT")
    shared_secret: str = Field(..., env="SHARED_SECRET")
    
    # Data directories
    data_dir: Path = Field(default_factory=lambda: Path.home() / ".northwen-bidwriter")
    uploads_dir: Optional[Path] = None
    exports_dir: Optional[Path] = None
    models_dir: Optional[Path] = None
    temp_dir: Optional[Path] = None
    
    # Database
    database_url: str = Field(default="sqlite:///./northwen_bidwriter.db")
    
    # AI Configuration
    default_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    max_context_length: int = 4096
    embedding_dimension: int = 384
    
    # Processing limits
    max_file_size: int = 50 * 1024 * 1024  # 50MB
    max_pages: int = 1000
    max_word_count: int = 500000
    
    # Security
    enable_virus_scanning: bool = True
    clamav_db_path: Optional[Path] = None
    
    # Logging
    log_level: str = "INFO"
    log_file: Optional[Path] = None
    
    # Performance
    max_workers: int = 4
    chunk_size: int = 1000
    batch_size: int = 32
    
    class Config:
        env_file = ".env"
        case_sensitive = False
    
    def __post_init__(self):
        """Initialize derived paths."""
        # Ensure data directory exists
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Set default subdirectories
        if self.uploads_dir is None:
            self.uploads_dir = self.data_dir / "uploads"
        if self.exports_dir is None:
            self.exports_dir = self.data_dir / "exports"
        if self.models_dir is None:
            self.models_dir = self.data_dir / "models"
        if self.temp_dir is None:
            self.temp_dir = self.data_dir / "temp"
        
        # Create directories
        for dir_path in [self.uploads_dir, self.exports_dir, self.models_dir, self.temp_dir]:
            dir_path.mkdir(parents=True, exist_ok=True)
        
        # Set log file if not specified
        if self.log_file is None:
            self.log_file = self.data_dir / "logs" / "engine.log"
            self.log_file.parent.mkdir(parents=True, exist_ok=True)


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    settings = Settings()
    settings.__post_init__()
    return settings
