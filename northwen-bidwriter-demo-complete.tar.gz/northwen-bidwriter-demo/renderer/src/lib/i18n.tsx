import React, { createContext, useContext, useEffect, useState } from 'react';
import i18n from 'i18next';
import { initReactI18next, useTranslation as useI18nTranslation } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

// Import translation files
import enCA from '@/assets/i18n/en-CA.json';
import frCA from '@/assets/i18n/fr-CA.json';

// Initialize i18next
i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      'en-CA': {
        translation: enCA
      },
      'fr-CA': {
        translation: frCA
      }
    },
    fallbackLng: 'en-CA',
    debug: process.env.NODE_ENV === 'development',
    
    interpolation: {
      escapeValue: false, // React already escapes values
    },
    
    detection: {
      order: ['localStorage', 'navigator', 'htmlTag'],
      caches: ['localStorage'],
      lookupLocalStorage: 'nw-language',
    },
  });

export interface I18nContextType {
  language: string;
  setLanguage: (lang: string) => void;
  availableLanguages: Array<{
    code: string;
    name: string;
    nativeName: string;
  }>;
}

const I18nContext = createContext<I18nContextType | undefined>(undefined);

export const availableLanguages = [
  {
    code: 'en-CA',
    name: 'English (Canada)',
    nativeName: 'English (Canada)'
  },
  {
    code: 'fr-CA',
    name: 'French (Canada)',
    nativeName: 'Français (Canada)'
  }
];

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState(i18n.language);

  const setLanguage = (lang: string) => {
    i18n.changeLanguage(lang);
    setLanguageState(lang);
    localStorage.setItem('nw-language', lang);
  };

  useEffect(() => {
    const handleLanguageChange = (lng: string) => {
      setLanguageState(lng);
    };

    i18n.on('languageChanged', handleLanguageChange);
    return () => {
      i18n.off('languageChanged', handleLanguageChange);
    };
  }, []);

  const value: I18nContextType = {
    language,
    setLanguage,
    availableLanguages,
  };

  return (
    <I18nContext.Provider value={value}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const context = useContext(I18nContext);
  if (context === undefined) {
    throw new Error('useI18n must be used within an I18nProvider');
  }
  return context;
}

// Enhanced translation hook with type safety
export function useTranslation() {
  const { t, i18n } = useI18nTranslation();
  const { language, setLanguage } = useI18n();

  return {
    t,
    i18n,
    language,
    setLanguage,
    isEnglish: language === 'en-CA',
    isFrench: language === 'fr-CA',
  };
}

// Utility function for formatting dates with locale
export function formatDate(date: Date | string, options?: Intl.DateTimeFormatOptions): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  const locale = i18n.language === 'fr-CA' ? 'fr-CA' : 'en-CA';
  
  const defaultOptions: Intl.DateTimeFormatOptions = {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    ...options,
  };
  
  return new Intl.DateTimeFormat(locale, defaultOptions).format(dateObj);
}

// Utility function for formatting numbers with locale
export function formatNumber(number: number, options?: Intl.NumberFormatOptions): string {
  const locale = i18n.language === 'fr-CA' ? 'fr-CA' : 'en-CA';
  return new Intl.NumberFormat(locale, options).format(number);
}

// Utility function for formatting currency
export function formatCurrency(amount: number, currency = 'CAD'): string {
  const locale = i18n.language === 'fr-CA' ? 'fr-CA' : 'en-CA';
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency,
  }).format(amount);
}

// Utility function for relative time formatting
export function formatRelativeTime(date: Date | string): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - dateObj.getTime()) / 1000);
  
  const locale = i18n.language === 'fr-CA' ? 'fr-CA' : 'en-CA';
  const rtf = new Intl.RelativeTimeFormat(locale, { numeric: 'auto' });
  
  if (diffInSeconds < 60) {
    return rtf.format(-diffInSeconds, 'second');
  } else if (diffInSeconds < 3600) {
    return rtf.format(-Math.floor(diffInSeconds / 60), 'minute');
  } else if (diffInSeconds < 86400) {
    return rtf.format(-Math.floor(diffInSeconds / 3600), 'hour');
  } else if (diffInSeconds < 2592000) {
    return rtf.format(-Math.floor(diffInSeconds / 86400), 'day');
  } else if (diffInSeconds < 31536000) {
    return rtf.format(-Math.floor(diffInSeconds / 2592000), 'month');
  } else {
    return rtf.format(-Math.floor(diffInSeconds / 31536000), 'year');
  }
}

export default i18n;
